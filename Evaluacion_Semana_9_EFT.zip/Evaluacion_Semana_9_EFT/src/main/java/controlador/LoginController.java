package controlador;

import DAO.UsuarioDAO;
import model.Usuario;
import vista.LoginView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class LoginController implements ActionListener {

    private LoginView vista;
    private UsuarioDAO usuarioDAO;

    public LoginController(LoginView vista) {
        this.vista = vista;
        this.usuarioDAO = new UsuarioDAO();

        this.vista.addLoginListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String correo = vista.getCorreo();
        String password = vista.getPassword();

        if (correo.isEmpty() || password.isEmpty()) {
            vista.mostrarMensaje("Por favor, complete todos los campos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Usuario usuario = usuarioDAO.autenticar(correo, password);

        if (usuario != null) {
            vista.mostrarMensaje("¡Bienvenido, " + usuario.getNombre() + "!\nRol: " + usuario.getRol(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
            vista.dispose(); // Cierra la ventana de login

        } else {
            vista.mostrarMensaje("Correo o contraseña incorrectos.", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
        }
    }
}
