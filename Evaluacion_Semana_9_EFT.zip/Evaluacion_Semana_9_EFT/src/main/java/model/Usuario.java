package model;

public class Usuario {

    private String contraseña;
    private String rol;

    public Usuario(int id, String nombre, String rut, String correo, String contraseña, String rol) {
        super();
        this.contraseña = contraseña;
        this.rol = rol;
    }

    public String getContraseña() { return contraseña; }
    public void setContraseña(String contraseña) { this.contraseña = contraseña; }

    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    public String getNombre() {
        return null;
    }
}
