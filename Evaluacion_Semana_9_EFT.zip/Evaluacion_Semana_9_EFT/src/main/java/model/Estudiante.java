package model;

public class Estudiante {

    private String curso;

    public Estudiante(int id, String nombre, String rut, String curso, String correo) {
        super();
        this.curso = curso;
    }

    public String getCurso() { return curso; }
    public void setCurso(String curso) { this.curso = curso; }
}

