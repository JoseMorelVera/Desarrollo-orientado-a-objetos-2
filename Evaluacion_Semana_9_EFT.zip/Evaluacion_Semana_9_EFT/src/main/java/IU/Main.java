package IU;

import controlador.LoginController;
import vista.LoginView;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            LoginView vista = new LoginView();
            new LoginController(vista);

            vista.setVisible(true);
        });
    }
}