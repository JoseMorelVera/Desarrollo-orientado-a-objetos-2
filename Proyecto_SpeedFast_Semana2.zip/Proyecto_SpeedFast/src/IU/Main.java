package IU;
import java.util.ArrayList;
import java.util.List;
import model.Pedido;
import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;

public class Main {
    public static void main(String[] args) {

        Pedido pedidoComida = new PedidoComida("001", "Av. Italia 456", 4.0);
        Pedido pedidoEncomienda = new PedidoEncomienda("002", "Av. Independencia 123", 6.0);
        Pedido pedidoExpress = new PedidoExpress("003", "Av. Apoquindo 1500", 7.0);

        List<Pedido> listaPedidos = new ArrayList<>();
        listaPedidos.add(pedidoComida);
        listaPedidos.add(pedidoEncomienda);
        listaPedidos.add(pedidoExpress);

        for (Pedido pedido : listaPedidos) {
            pedido.mostrarResumen();
        }
    }
}