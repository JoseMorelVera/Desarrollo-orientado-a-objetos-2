package util;

import model.Pedido;

import java.util.ArrayList;
import java.util.List;

public class ControladorDeEnvios implements Rastreable {
    private List<Pedido> historialEntregas = new ArrayList<>();

    public void registrarEntrega(Pedido pedido) {
        if (pedido != null) {
            historialEntregas.add(pedido);
        }
    }

    public List<Pedido> getHistorialEntregas() {
        return historialEntregas;
    }

    @Override
    public void verHistorial() {
        System.out.println("Historial:");
        for (Pedido p : historialEntregas) {
            System.out.println("- " + p.getClass().getSimpleName() + " #" + p.getId() + " – entregado por " + p.getRepartidor());
        }
    }
}
