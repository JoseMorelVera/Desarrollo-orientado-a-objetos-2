package dao;

import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import dao.*;

public class PedidoDAO {

    public boolean guardar(Pedido pedido, String tipoStr) {
        String sql = "INSERT INTO pedido (direccion, tipo, estado) VALUES (?, ?, ?)";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, pedido.getDireccion());
            stmt.setString(2, tipoStr.toUpperCase());
            stmt.setString(3, pedido.getEstado().name());

            int filas = stmt.executeUpdate();
            if (filas > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    pedido.setId(rs.getInt(1)); // Asigna el ID auto-generado por MySQL
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Pedido> listarTodos() {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedido";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String direccion = rs.getString("direccion");
                String tipo = rs.getString("tipo");
                String estadoStr = rs.getString("estado");

                Pedido p;
                switch (tipo.toUpperCase()) {
                    case "COMIDA":
                        p = new PedidoComida(id, direccion, 5.0);
                        break;
                    case "ENCOMIENDA":
                        p = new PedidoEncomienda(id, direccion, 5.0);
                        break;
                    default:
                        p = new PedidoExpress(id, direccion, 5.0);
                        break;
                }
                p.setEstado(EstadoPedido.valueOf(estadoStr));
                lista.add(p);

            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return lista;

    }
}
