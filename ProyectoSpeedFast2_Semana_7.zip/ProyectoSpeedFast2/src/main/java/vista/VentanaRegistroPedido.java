package vista;

import model.*;
import util.ControladorDeEnvios;
import dao.*;
import javax.swing.*;
import java.awt.*;

public class VentanaRegistroPedido extends JFrame{

    private JTextField txtId;
    private JTextField txtDireccion;
    private JTextField txtDistancia;
    private JComboBox<String> cbTipo;

    public VentanaRegistroPedido(ControladorDeEnvios controlador, ZonaDeCarga zonaDeCarga) {
        setTitle("Registrar Nuevo Pedido");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 2, 5, 5));

        add(new JLabel("ID Pedido:"));
        txtId = new JTextField();
        add(txtId);

        add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        add(txtDireccion);

        add(new JLabel("Distancia (Km):"));
        txtDistancia = new JTextField();
        add(txtDistancia);

        add(new JLabel("Tipo de Pedido:"));
        cbTipo = new JComboBox<>(new String[]{"Comida", "Encomienda", "Express"});
        add(cbTipo);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String direccion = txtDireccion.getText().trim();
                double distancia = Double.parseDouble(txtDistancia.getText().trim());
                String tipo = (String) cbTipo.getSelectedItem();

                if (direccion.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "La dirección no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Pedido nuevoPedido;
                switch (tipo) {
                    case "Comida":
                        nuevoPedido = new PedidoComida(id, direccion, distancia);
                        break;
                    case "Encomienda":
                        nuevoPedido = new PedidoEncomienda(id, direccion, distancia);
                        break;
                    default:
                        nuevoPedido = new PedidoExpress(id, direccion, distancia);
                        break;
                }

                PedidoDAO pedidoDAO = new PedidoDAO();
                boolean exito = pedidoDAO.guardar(nuevoPedido, tipo);

                if (exito) {
                    JOptionPane.showMessageDialog(this, "Pedido guardado con éxito en la Base de Datos.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Error al guardar el pedido en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
                }

                nuevoPedido.asignarRepartidor();
                controlador.registrarEntrega(nuevoPedido);
                zonaDeCarga.agregarPedido(nuevoPedido);

                JOptionPane.showMessageDialog(this, "Pedido registrado con éxito.");
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID y Distancia deben ser valores numéricos válidos.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            }

        });

        add(new JLabel()); // Espaciador
        add(btnGuardar);
    }
}
