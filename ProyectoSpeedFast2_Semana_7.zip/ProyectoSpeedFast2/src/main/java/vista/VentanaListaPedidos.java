package vista;

import model.Pedido;
import util.ControladorDeEnvios;
import dao.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaListaPedidos extends JFrame{

    public VentanaListaPedidos(ControladorDeEnvios controlador) {
        setTitle("Listado de Pedidos");
        setSize(500, 300);
        setLocationRelativeTo(null);

        String[] columnas = {"ID", "Tipo", "Dirección", "Distancia (Km)", "Estado", "Repartidor"};
        DefaultTableModel model = new DefaultTableModel(columnas, 0);

        for (Pedido p : controlador.getHistorialEntregas()) {
            Object[] fila = {
                    p.getId(),
                    p.getClass().getSimpleName().replace("Pedido", ""),
                    p.getDireccion(),
                    p.getDistanciaKm(),
                    p.getEstado(),
                    p.getRepartidor()
            };
            model.addRow(fila);
        }

        PedidoDAO pedidoDAO = new PedidoDAO();
        List<Pedido> pedidosBD = pedidoDAO.listarTodos();

        for (Pedido p : pedidosBD) {
            Object[] fila = {
                    p.getId(),
                    p.getClass().getSimpleName().replace("Pedido", ""),
                    p.getDireccion(),
                    p.getDistanciaKm(),
                    p.getEstado(),
                    p.getRepartidor()
            };
            model.addRow(fila);
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }
}
