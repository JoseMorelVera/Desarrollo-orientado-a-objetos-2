package vista;

import model.ZonaDeCarga;
import util.ControladorDeEnvios;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame{

    private ControladorDeEnvios controlador;
    private ZonaDeCarga zonaDeCarga;

    public VentanaPrincipal(ControladorDeEnvios controlador, ZonaDeCarga zonaDeCarga) {
        this.controlador = controlador;
        this.zonaDeCarga = zonaDeCarga;

        setTitle("SpeedFast - Gestión de Entregas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 1, 10, 10));

        JButton btnRegistrar = new JButton("Registrar Pedido");
        JButton btnListar = new JButton("Listar Pedidos");
        JButton btnAsignar = new JButton("Asignar Repartidor / Iniciar Entrega");

        btnRegistrar.addActionListener(e -> {
            VentanaRegistroPedido regFrame = new VentanaRegistroPedido(controlador, zonaDeCarga);
            regFrame.setVisible(true);
        });

        btnListar.addActionListener(e -> {
            VentanaListaPedidos listFrame = new VentanaListaPedidos(controlador);
            listFrame.setVisible(true);
        });

        btnAsignar.addActionListener(e -> {
            if (zonaDeCarga.estaVacia()) {
                JOptionPane.showMessageDialog(this, "No hay pedidos en la zona de carga para entregar.");
            } else {
                JOptionPane.showMessageDialog(this, "Iniciando proceso de reparto concurrente...");
                // Aquí se puede lanzar un Hilo con Repartidor
            }
        });

        add(btnRegistrar);
        add(btnListar);
        add(btnAsignar);
    }
}
