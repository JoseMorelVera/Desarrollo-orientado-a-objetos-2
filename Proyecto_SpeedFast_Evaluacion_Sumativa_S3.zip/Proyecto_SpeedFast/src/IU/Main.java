package IU;
import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;
import util.ControladorDeEnvios;

public class Main {
    public static void main(String[] args) {
        ControladorDeEnvios controlador = new ControladorDeEnvios();

        PedidoComida pedidoComida = new PedidoComida(101, "Calle Los Aromos 123", 4.0);
        pedidoComida.asignarRepartidor("Luis Díaz");
        pedidoComida.setEstado("Despachado");
        controlador.registrarEntrega(pedidoComida);

        System.out.println("[Pedido Encomienda]");
        PedidoEncomienda pedidoEncomienda = new PedidoEncomienda(102, "Av. Santa Rosa 567", 7.0);

        pedidoEncomienda.asignarRepartidor("Daniela Tapia");
        pedidoEncomienda.mostrarResumen();
        pedidoEncomienda.despachar();
        controlador.registrarEntrega(pedidoEncomienda);

        PedidoExpress pedidoExpress = new PedidoExpress(103, "Plaza Central 45", 2.0);

        pedidoExpress.asignarRepartidor();
        pedidoExpress.cancelar();
        controlador.registrarEntrega(pedidoExpress);
        
        controlador.verHistorial();
        }
}