package util;

public interface Cancelable {
    void despachar();
}
