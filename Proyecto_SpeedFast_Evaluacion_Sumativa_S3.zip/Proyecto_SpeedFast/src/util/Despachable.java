package util;

public interface Despachable {
    void cancelar();
}
