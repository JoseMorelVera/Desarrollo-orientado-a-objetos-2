package model;


import util.Cancelable;
import util.Despachable;

public abstract class Pedido implements Cancelable, Despachable {
    protected int id;
    protected String direccion;
    protected double distanciaKm;
    protected String repartidor;
    protected EstadoPedido estado;

    public Pedido(int id, String direccion, double distanciaKm) {
        this.id = id;
        this.direccion = direccion;
        this.distanciaKm = distanciaKm;
        this.estado = EstadoPedido.PENDIENTE;
        this.repartidor = "Pendiente de asignación";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getDistanciaKm() {
        return distanciaKm;
    }

    public void setDistanciaKm(double distanciaKm) {
        this.distanciaKm = distanciaKm;
    }

    public void setRepartidor(String repartidor) {
        this.repartidor = repartidor;
    }

    public EstadoPedido getEstado() {
        return estado;
    }

    public void setEstado(EstadoPedido estado) {
        this.estado = estado;
    }

    public abstract void calcularTiempoEntrega();

    public void asignarRepartidor() {
        this.repartidor = "Repartidor Genérico";
    }

    public void asignarRepartidor(String nombre) {
        this.repartidor = nombre;
    }

    public void mostrarResumen() {
        System.out.println("Pedido #" + id);
        System.out.println("Dirección: " + direccion);
        System.out.println("Distancia: " + (int)distanciaKm + " km");
        System.out.println("Repartidor asignado: " + repartidor);
        calcularTiempoEntrega();
    }

    @Override
    public void despachar() {
        this.estado = EstadoPedido.valueOf("Despachado");
        System.out.println("Pedido despachado correctamente.");
    }

    @Override
    public void cancelar() {
        this.estado = EstadoPedido.valueOf("Cancelado");
        System.out.println("Cancelando Pedido " + this.getClass().getSimpleName().replace("Pedido", "") + " #" + id + "...");
        System.out.println("→ Pedido cancelado exitosamente.");
    }

    public String getRepartidor() {
        return this.repartidor;
    }

    @Override
    public String toString() {
        return "Pedido #" + id + "- Destino: " + direccion;
    }
}