package IU;
import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;
import util.ControladorDeEnvios;
import model.Pedido;
import model.Repartidor;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import model.ZonaDeCarga;

public class Main {
    public static void main(String[] args) {

        System.out.println("[Zona de carga inicializada]");
        ZonaDeCarga zonaDeCarga = new ZonaDeCarga();

        zonaDeCarga.agregarPedido(new PedidoExpress(1, "Santiago Centro", 5.0));
        zonaDeCarga.agregarPedido(new PedidoComida(2, "Providencia", 3.0));
        zonaDeCarga.agregarPedido(new PedidoEncomienda(3, "Ñuñoa", 10.0));
        zonaDeCarga.agregarPedido(new PedidoExpress(4, "Recoleta", 4.5));
        zonaDeCarga.agregarPedido(new PedidoComida(5, "Las Condes", 8.0));

        Thread t1 = new Thread(new Repartidor("Juan", zonaDeCarga));
        Thread t2 = new Thread(new Repartidor("Camila", zonaDeCarga));
        Thread t3 = new Thread(new Repartidor("Pedro", zonaDeCarga));

        t1.start();
        t2.start();
        t3.start();

        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("[Zona de carga vacía]");
        System.out.println("Todos los pedidos han sido entregados correctamente.");
    }

}