package model;

public class Pedido {
    private int idPedido;
    private String direccionEntrega;
    private String tipoPedido;

    /**
     * Constructor de la clase pedido
     *
     * @param idPedido numero de identificacion del pedido
     * @param direccionEntrega direccion de entrega del pedido
     * @param tipoPedido tipo de pedido
     */
    public Pedido(int idPedido, String direccionEntrega, String tipoPedido) {
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega;
        this.tipoPedido = tipoPedido;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public void asignarRepartidor() {
        System.out.println("=== SISTEMA SPEEDFAST ===");
        System.out.println("Tipo: " + tipoPedido + " | ID Pedido: #" + idPedido);
        System.out.println("Dirección: " + direccionEntrega);
        System.out.println("Estado: Buscando repartidor general en la zona...");
    }

    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("=== SISTEMA SPEEDFAST ===");
        System.out.println("Tipo: " + tipoPedido + " | ID Pedido: #" + idPedido);
        System.out.println("Dirección: " + direccionEntrega);
        System.out.println("Asignado exitosamente a: " + nombreRepartidor);
    }
}
