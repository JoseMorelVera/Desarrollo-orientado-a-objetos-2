package model;

public class PedidoEncomienda extends Pedido {
    public PedidoEncomienda(int idPedido, String direccionEntrega) {
        super(idPedido, direccionEntrega, "Encomiendas (Paquetes/Documentos)");
    }

    @Override
    public void asignarRepartidor() {
        super.asignarRepartidor();
        System.out.println("[Validación] Comprobando límites de peso y calidad del embalaje... OK");
        System.out.println("[Notificación] Generando orden de retiro para encomienda.");
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("=== SISTEMA SPEEDFAST ===");
        System.out.println("Tipo: " + getTipoPedido() + " | ID Pedido: #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("[Validación] Peso y embalaje autorizados.");
        System.out.println("--> Encomienda asignada oficialmente a: " + nombreRepartidor);
    }
}
