package model;

public class PedidoExpress extends Pedido{

    public PedidoExpress(int idPedido, String direccionEntrega) {
        super(idPedido, direccionEntrega, "Compras Express (Supermercado/Farmacia)");
    }

    @Override
    public void asignarRepartidor() {
        super.asignarRepartidor();
        System.out.println("[Geolocalización] Rastreando unidades más cercanas...");
        System.out.println("[Notificación] Disponibilidad inmediata requerida.");
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("=== SISTEMA SPEEDFAST ===");
        System.out.println("Tipo: " + getTipoPedido() + " | ID Pedido: #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("[Geolocalización] Repartidor con menor tiempo de llegada identificado.");
        System.out.println("--> Compra Express asignada a: " + nombreRepartidor);
    }

}
