package model;

public class PedidoComida extends Pedido{

    public PedidoComida(int idPedido, String direccionEntrega) {
        super(idPedido, direccionEntrega,"Comida (Restaurantes)");
    }

    @Override
    public void asignarRepartidor() {
        super.asignarRepartidor();
        System.out.println("[Validación] Verificando equipamiento: Mochila térmica requerida... OK");
        System.out.println("[Notificación] Esperando confirmación del repartidor asignado.");
    }

    @Override
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("=== SISTEMA SPEEDFAST ===");
        System.out.println("Tipo: " + getTipoPedido() + " | ID Pedido: #" + getIdPedido());
        System.out.println("Dirección: " + getDireccionEntrega());
        System.out.println("[Validación] Mochila térmica verificada para " + nombreRepartidor + ".");
        System.out.println("--> Pedido de Comida confirmado para: " + nombreRepartidor);
    }
}
