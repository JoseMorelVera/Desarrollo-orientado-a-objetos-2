package IU;
import java.util.ArrayList;
import java.util.List;
import model.Pedido;
import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;

public class Main {
    public static void main(String[] args) {

        List<Pedido> listaPedidos = new ArrayList<>();

        listaPedidos.add(new PedidoComida(1001, "Av. Las Condes #1230"));
        listaPedidos.add(new PedidoEncomienda(1002, "Calle Moneda #850"));
        listaPedidos.add(new PedidoExpress(1003, "Av. Vicuña Mackenna #450"));

        System.out.println("**************************************************");
        System.out.println("   PRUEBA DE POLIMORFISMO: MÉTODOS SOBRESCRITOS");
        System.out.println("**************************************************\n");

        for (Pedido p : listaPedidos) {
            p.asignarRepartidor();
            System.out.println("--------------------------------------------------\n");
        }

        System.out.println("**************************************************");
        System.out.println("   PRUEBA DE POLIMORFISMO: MÉTODOS SOBRECARGADOS");
        System.out.println("**************************************************\n");

        listaPedidos.get(0).asignarRepartidor("Juan Pérez");
        System.out.println("--------------------------------------------------\n");

        listaPedidos.get(1).asignarRepartidor("Camila Soto");
        System.out.println("--------------------------------------------------\n");

        listaPedidos.get(2).asignarRepartidor("Luis Díaz");
        System.out.println("--------------------------------------------------\n");
    }
}