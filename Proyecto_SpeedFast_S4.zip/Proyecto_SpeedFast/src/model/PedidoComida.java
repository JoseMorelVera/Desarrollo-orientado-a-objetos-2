package model;

public class PedidoComida extends Pedido {

    public PedidoComida(int id, String direccion, double distanciaKm) {
        super(id, direccion, distanciaKm);
    }

    @Override
    public void calcularTiempoEntrega() {
        int tiempo = (int) (distanciaKm * 3 + 15);
        System.out.println("Tiempo estimado: " + tiempo + " minutos");
    }

    @Override
    public void asignarRepartidor() {
        this.repartidor = "Repartidor en Moto (Asignación Automática)";
    }

}
