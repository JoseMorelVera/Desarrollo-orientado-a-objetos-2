package model;

import java.util.List;
import java.util.Random;

public class Repartidor implements Runnable {

    private String nombre;
    private List<Pedido> pedidos;

    public Repartidor(String nombre, List<Pedido> pedidos) {
        this.nombre = nombre;
        this.pedidos = pedidos;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    @Override
    public void run() {
        Random random = new Random();

        for (Pedido pedido : pedidos) {

            System.out.println("[Repartidor: " + nombre + "] Entregando "
                    + pedido.getClass().getSimpleName() + " #" + pedido.getId() + "...");

            try {
                int tiempoSimulado = 1000 + random.nextInt(2000);
                Thread.sleep(tiempoSimulado);

                pedido.despachar();

                System.out.println("[Repartidor: " + nombre + "] Pedido #" + pedido.getId() + " entregado.");

            } catch (InterruptedException e) {
                System.err.println("[Repartidor: " + nombre + "] Ocurrió una interrupción en el pedido #"
                        + pedido.getId() + ": " + e.getMessage());
                Thread.currentThread().interrupt();
            }
        }
    }
}
