package model;

public class PedidoEncomienda extends Pedido {

    public PedidoEncomienda(int id, String direccion, double distanciaKm) {
        super(id, direccion, distanciaKm);
    }

    @Override
    public void calcularTiempoEntrega() {
        int tiempo = (int) (distanciaKm * 4 + 2);
        System.out.println("Tiempo estimado: " + tiempo + " minutos");
    }

    @Override
    public void asignarRepartidor() {
        this.repartidor = "Repartidor en Furgón (Asignación Automática)";
    }
}
