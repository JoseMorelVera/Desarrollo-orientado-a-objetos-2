package model;

public class PedidoExpress extends Pedido {

    public PedidoExpress(int id, String direccion, double distanciaKm) {
        super(id, direccion, distanciaKm);
    }

    @Override
    public void calcularTiempoEntrega() {
        int tiempo = (int) (distanciaKm * 2);
        System.out.println("Tiempo estimado: " + tiempo + " minutos");
    }

    @Override
    public void asignarRepartidor() {
        this.repartidor = "Repartidor Express (Asignación Automática)";
    }
}