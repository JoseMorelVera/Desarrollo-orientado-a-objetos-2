package util;

public interface Despachable {
    void despachar();
}
