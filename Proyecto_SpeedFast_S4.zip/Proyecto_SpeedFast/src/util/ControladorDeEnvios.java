package util;

import model.Pedido;

import java.util.ArrayList;
import java.util.List;

public class ControladorDeEnvios implements Rastreable {
    private List<Pedido> historialEntregas = new ArrayList<>();

    public void registrarEntrega(Pedido pedido) {
        if (!pedido.getEstado().equals("Cancelado")) {
            historialEntregas.add(pedido);
        }
    }

    @Override
    public void verHistorial() {
        System.out.println("Historial:");
        for (Pedido p : historialEntregas) {
            System.out.println("- " + p.getClass().getSimpleName() + " #" + p.getId() + " – entregado por " + p.getRepartidor());
        }
    }
}
