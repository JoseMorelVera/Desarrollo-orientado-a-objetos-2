package util;

public interface Rastreable {
    void verHistorial();
}
