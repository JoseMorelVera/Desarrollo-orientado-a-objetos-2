package IU;
import model.PedidoComida;
import model.PedidoEncomienda;
import model.PedidoExpress;
import util.ControladorDeEnvios;
import model.Pedido;
import model.Repartidor;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA SPEEDFAST: SIMULACIÓN DE ENTREGAS PARALELAS ===\n");

        Pedido p1 = new PedidoComida(101, "Av. Italia 123", 4.5);
        Pedido p2 = new PedidoExpress(102, "Calle Las Heras 456", 2.0);
        Pedido p3 = new PedidoEncomienda(103, "Av. Providencia 789", 10.0);
        Pedido p4 = new PedidoComida(104, "Pasaje El Roble 321", 3.2);
        Pedido p5 = new PedidoExpress(105, "Av. Apoquindo 654", 5.5);
        Pedido p6 = new PedidoEncomienda(106, "Calle San Martin 987", 8.0);

        List<Pedido> pedidosCamila = new ArrayList<>();
        pedidosCamila.add(p1);
        pedidosCamila.add(p4);

        List<Pedido> pedidosLuis = new ArrayList<>();
        pedidosLuis.add(p2);
        pedidosLuis.add(p5);

        List<Pedido> pedidosCarlos = new ArrayList<>();
        pedidosCarlos.add(p3);
        pedidosCarlos.add(p6);

        Repartidor repartidor1 = new Repartidor("Camila", pedidosCamila);
        Repartidor repartidor2 = new Repartidor("Luis", pedidosLuis);
        Repartidor repartidor3 = new Repartidor("Carlos", pedidosCarlos);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.execute(repartidor1);
        executor.execute(repartidor2);
        executor.execute(repartidor3);

        executor.shutdown();

        try {
            if (executor.awaitTermination(1, TimeUnit.MINUTES)) {
                System.out.println("\n=== TODAS LAS ENTREGAS FUERON COMPLETADAS EXITOSAMENTE ===");
            } else {
                System.out.println("\n--- La simulación excedió el tiempo máximo de espera ---");
            }
        } catch (InterruptedException e) {
            System.err.println("La simulación principal fue interrumpida: " + e.getMessage());
        }
    }

}