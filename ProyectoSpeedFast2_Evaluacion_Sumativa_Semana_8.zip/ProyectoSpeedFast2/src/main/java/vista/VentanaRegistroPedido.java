package vista;

import model.*;
import util.ControladorDeEnvios;
import dao.*;
import javax.swing.*;
import java.awt.*;

public class VentanaRegistroPedido extends JFrame{

    private JTextField txtDireccion;
    private JComboBox<String> cbTipo;
    private JComboBox<String> cbEstado;

    public VentanaRegistroPedido(ControladorDeEnvios controlador, ZonaDeCarga zonaDeCarga) {
        setTitle("Registrar Nuevo Pedido");
        setSize(380, 250);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 5, 5));

        add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        add(txtDireccion);

        add(new JLabel("Tipo de Pedido:"));
        cbTipo = new JComboBox<>(new String[]{"COMIDA", "ENCOMIENDA", "EXPRESS"});
        add(cbTipo);

        add(new JLabel("Estado:"));
        cbEstado = new JComboBox<>(new String[]{"PENDIENTE", "EN_REPARTO", "ENTREGADO"});
        add(cbEstado);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(e -> {
            String direccion = txtDireccion.getText().trim();
            String tipo = (String) cbTipo.getSelectedItem();
            String estado = (String) cbEstado.getSelectedItem();

            if (direccion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "La dirección no puede estar vacía.", "Validación", JOptionPane.WARNING_MESSAGE);
                return;
            }

            PedidoDAO dao = new PedidoDAO();
            boolean exito = dao.create(direccion, tipo, estado);

            if (exito) {
                JOptionPane.showMessageDialog(this, "Pedido guardado con éxito en la BD.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar el pedido en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        add(new JLabel());
        add(btnGuardar);
    }
}
