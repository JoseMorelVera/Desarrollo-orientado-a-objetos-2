package UI;


import model.ZonaDeCarga;
import util.ControladorDeEnvios;
import vista.VentanaPrincipal;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ControladorDeEnvios controlador = new ControladorDeEnvios();
            ZonaDeCarga zonaDeCarga = new ZonaDeCarga();
            VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(controlador, zonaDeCarga);
            JFrame frame = new JFrame("SpeedFast - Gestión de Pedidos");

            frame.setContentPane(ventanaPrincipal.getContentPane());

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            frame.setSize(500, 400);
            frame.setLocationRelativeTo(null);

            frame.setVisible(true);
        });
    }

}