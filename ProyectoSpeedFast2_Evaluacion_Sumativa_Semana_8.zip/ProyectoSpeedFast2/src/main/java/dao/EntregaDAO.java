package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.*;

public class EntregaDAO {

    public boolean create(int idPedido, int idRepartidor, Date fecha, Time hora) {
        String sql = "INSERT INTO entregas (id_pedido, id_repartidor, fecha, hora) VALUES (?, ?, ?, ?)";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idPedido);
            stmt.setInt(2, idRepartidor);
            stmt.setDate(3, fecha);
            stmt.setTime(4, hora);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Object[]> readAll() {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT e.id, p.direccion, r.nombre, e.fecha, e.hora " +
                "FROM entregas e " +
                "JOIN pedidos p ON e.id_pedido = p.id " +
                "JOIN repartidores r ON e.id_repartidor = r.id";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lista.add(new Object[]{
                        rs.getInt("id"),
                        rs.getString("direccion"),
                        rs.getString("nombre"),
                        rs.getDate("fecha"),
                        rs.getTime("hora")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM entregas WHERE id = ?";
        try (Connection conn = ConexionDB.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
