package dao;

import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import dao.*;

public class PedidoDAO {

        public boolean create(String direccion, String tipo, String estado) {
            String sql = "INSERT INTO pedidos (direccion, tipo, estado) VALUES (?, ?, ?)";
            try (Connection conn = ConexionDB.getConexion();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, direccion);
                stmt.setString(2, tipo.toUpperCase());
                stmt.setString(3, estado.toUpperCase());
                return stmt.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        public List<Object[]> readAll() {
            List<Object[]> lista = new ArrayList<>();
            String sql = "SELECT * FROM pedidos";
            try (Connection conn = ConexionDB.getConexion();
                 PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{
                            rs.getInt("id"),
                            rs.getString("direccion"),
                            rs.getString("tipo"),
                            rs.getString("estado")
                    });
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return lista;
        }

        public boolean update(int id, String direccion, String tipo, String estado) {
            String sql = "UPDATE pedidos SET direccion = ?, tipo = ?, estado = ? WHERE id = ?";
            try (Connection conn = ConexionDB.getConexion();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, direccion);
                stmt.setString(2, tipo.toUpperCase());
                stmt.setString(3, estado.toUpperCase());
                stmt.setInt(4, id);
                return stmt.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

        public boolean delete(int id) {
            String sql = "DELETE FROM pedidos WHERE id = ?";
            try (Connection conn = ConexionDB.getConexion();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, id);
                return stmt.executeUpdate() > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }

    public java.awt.List listarTodos() {
    }
}
